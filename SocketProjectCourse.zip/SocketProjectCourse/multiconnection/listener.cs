﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
namespace multiconnectionserver
{
  public class listener
    {
        Socket s;
        public bool listening
        {
            get;
            private set;
        }
        public int port
        {
            get;
            private set;
        }
        public listener(int port)
        {
            this.port = port;
            s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }
        public void start()
        {
            if (listening) return;
            s.Bind(new IPEndPoint(0, port));
            s.Listen(0);
            s.BeginAccept(callback, null);
            listening = true;
        }
        public void stop()
        {
            if (!listening) return;
            s.Close();
            s.Dispose();
            s = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }
        void callback(IAsyncResult iar)
        {
            try
            {
                Socket s = this.s.EndAccept(iar);
                if(socketaccepted != null)
                {
                    socketaccepted(s);
                }
                this.s.BeginAccept(callback, null);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                throw;
            }
        }
        public delegate void SocketacceptedHandler(Socket e);
        public event SocketacceptedHandler socketaccepted;

    }
}
