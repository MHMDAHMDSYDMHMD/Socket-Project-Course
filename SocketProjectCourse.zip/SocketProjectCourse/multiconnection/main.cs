﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using multiconnectionserver;

namespace multiconnection
{
    public partial class main : Form
    {
        listener lis;
        public main()
        {
            InitializeComponent();
            lis = new listener(9);
            lis.socketaccepted += new listener.SocketacceptedHandler(Lis_socketaccepted);
            Load += new EventHandler(Main_Load);
        }

        private void Main_Load(object sender, EventArgs e)
        {
            lis.start();
        }

        private void Lis_socketaccepted(Socket e)
        {
            clientofmutlipleconnection client = new clientofmutlipleconnection(e);
            client.received += new  clientofmutlipleconnection.clientreceivedhandler(Client_received);
            client.disconnect += new clientofmutlipleconnection.clientdisconnecthandler(Client_disconnect);
            Invoke((MethodInvoker)delegate{
                ListViewItem i = new ListViewItem();
                i.Text = client.endpoint.ToString();
                i.SubItems.Add(client.id);
                i.SubItems.Add("XX");
                i.SubItems.Add("XX");
                i.Tag = client;
                lstclient.Items.Add(i);
            });
        }

        private void Client_disconnect(clientofmutlipleconnection sender)
        {
            Invoke((MethodInvoker)delegate
            {
                for (int i = 0; i < lstclient.Items.Count; i++)
                {
                    clientofmutlipleconnection cli = lstclient.Items[i].Tag as clientofmutlipleconnection;
                    if (cli.id == sender.id)
                    {
                        lstclient.Items.RemoveAt(i);
                        break;
                    }
                }
            });
        }

        private void Client_received(clientofmutlipleconnection sender, byte[] data)
        {
            Invoke((MethodInvoker)delegate {
                for (int i = 0; i < lstclient.Items.Count; i++)
                {

                    clientofmutlipleconnection cli = lstclient.Items[i].Tag as clientofmutlipleconnection;
                    if (cli.id == sender.id)
                    {
                        lstclient.Items[i].SubItems[2].Text = Encoding.Default.GetString(data);
                        lstclient.Items[i].SubItems[3].Text = DateTime.Now.ToString();
                        break;
                    }
               }
            });
       }

        private void main_Load(object sender, EventArgs e)
        {

        }
    }
}
