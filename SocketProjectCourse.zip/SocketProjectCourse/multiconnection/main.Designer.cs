﻿namespace multiconnection
{
    partial class main
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstclient = new System.Windows.Forms.ListView();
            this.endpoint = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.id = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lastmessage = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.lastreceivetime = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.SuspendLayout();
            // 
            // lstclient
            // 
            this.lstclient.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.endpoint,
            this.id,
            this.lastmessage,
            this.lastreceivetime});
            this.lstclient.Location = new System.Drawing.Point(2, 2);
            this.lstclient.Name = "lstclient";
            this.lstclient.Size = new System.Drawing.Size(804, 341);
            this.lstclient.TabIndex = 0;
            this.lstclient.UseCompatibleStateImageBehavior = false;
            this.lstclient.View = System.Windows.Forms.View.Details;
            // 
            // endpoint
            // 
            this.endpoint.Width = 136;
            // 
            // id
            // 
            this.id.Width = 172;
            // 
            // lastmessage
            // 
            this.lastmessage.Width = 261;
            // 
            // lastreceivetime
            // 
            this.lastreceivetime.Width = 215;
            // 
            // main
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(807, 346);
            this.Controls.Add(this.lstclient);
            this.Name = "main";
            this.Text = "main";
            this.Load += new System.EventHandler(this.main_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListView lstclient;
        private System.Windows.Forms.ColumnHeader endpoint;
        private System.Windows.Forms.ColumnHeader id;
        private System.Windows.Forms.ColumnHeader lastmessage;
        private System.Windows.Forms.ColumnHeader lastreceivetime;
    }
}