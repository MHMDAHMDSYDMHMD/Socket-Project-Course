﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
namespace ClientSide
{
    class Program
    {
        static Socket sck;

        static void Main(string[] args)
        {

            sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            IPEndPoint localEndpoint = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 1234);
            try
            {
                sck.Connect(localEndpoint);
            }
            catch (Exception)
            {

                Console.WriteLine("unable to connect to remote endpoint !!!!");
                Main(args);
            }
            Console.Write("enter text : ");
            string text = Console.ReadLine();
            byte[] data = Encoding.ASCII.GetBytes(text);
            sck.Send(data);
            Console.WriteLine("data sent!");
            sck.Close();
        }
    }
}
