﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multiconnectionclient
{
    public partial class clientmain : Form
    {
        Socket sck;
        public clientmain()
        {
            InitializeComponent();
            sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
        }

        private void clientmain_Load(object sender, EventArgs e)
        {

        }

        private void connect_Click(object sender, EventArgs e)
        {
            sck.Connect("127.0.0.1", 9);
            MessageBox.Show("connected");
        }

        private void send_Click(object sender, EventArgs e)
        {
            int cou = sck.Send(Encoding.Default.GetBytes(txtmessage.Text));
            if (cou>0)
            {
                MessageBox.Show("data sent");

            }
        }

        private void close_Click(object sender, EventArgs e)
        {
            sck.Close();
            sck.Dispose();
            Close();
        }
    }
}
