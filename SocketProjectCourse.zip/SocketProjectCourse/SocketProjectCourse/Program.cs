﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;

 namespace SocketProjectCourse
{
    public class Program
    {
        static byte[] buffer { get; set; }
        static Socket sck;
        public static void Main(string[] args)
        {
            sck = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            sck.Bind(new IPEndPoint(0, 1234));
            sck.Listen(100);
            Socket accepted = sck.Accept();
            buffer = new byte[accepted.SendBufferSize];
            int bytesread = accepted.Receive(buffer);
            byte[] formattd = new byte[bytesread];
            for (int i = 0; i < bytesread; i++)
            {
                formattd[i] = buffer[i];
            }
            string strdata = Encoding.ASCII.GetString(formattd);
            Console.WriteLine(strdata + "\r");
            Console.ReadKey();
            sck.Close();
            accepted.Close();

        }
    }
}
