﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.IO;
namespace serverasync
{
    enum Commands :int
    {
        String = 0,
        Image 
    }
    struct receivebuffer
    {
        public const int Buffer_Size = 1024;
        public byte[] buffer;
        public int toreceive;
        public MemoryStream bufferstream;
        
        public receivebuffer(int torec)
        {
            buffer = new byte[Buffer_Size];
            toreceive = torec;
            bufferstream = new MemoryStream(torec);
        }
        public void Dispose()
        {
            buffer = null;
            toreceive = 0;
            Close();
            if (bufferstream != null)
                bufferstream.Dispose();
        }
        private void Close()
        {
            if (bufferstream != null  && bufferstream.CanWrite)
            {
                bufferstream.Close();
            }
        }
    }
    class client
    {
        byte[] len;
        receivebuffer buffer;
        Socket socket;

        public IPEndPoint endppoint
        {
            get
            {
                if (socket != null && socket.Connected)
                {
                    return (IPEndPoint)socket.RemoteEndPoint;
                }
                return new IPEndPoint(IPAddress.None, 0);
            }
        }
        public delegate void disconnectedeventhandler(client sender);
        public event disconnectedeventhandler disconnected;
        public delegate void datarecieveeventhandler(client sender,receivebuffer e);
        public event datarecieveeventhandler datarecieve;

        public client(Socket s)
        {
            socket = s;
            len = new byte[4];
        }
        public void close()
        {
            if (socket != null)
            {
                socket.Disconnect(false);
                socket.Close();
            }
            buffer.Dispose();
            socket = null;
            len = null;
            disconnected = null;
            datarecieve = null;
        }
        public void receiveasync()
        {
            socket.BeginReceive(len, 0, len.Length, SocketFlags.None, receivecallback, null);
        }
        void receivecallback(IAsyncResult iar)
        {
            try
            {
                int rec = socket.EndReceive(iar);
                if (rec == 0)
                {
                    if (disconnected != null)
                    {
                        disconnected(this);
                        return;
                    }
                    if (rec!=4)
                    {
                        throw new Exception();
                    }
                }
            }
            catch (SocketException se)
            {
                switch (se.SocketErrorCode)
                {
                    case SocketError.ConnectionAborted:
                    case SocketError.ConnectionReset:
                        if (disconnected!=null)
                        {
                            disconnected(this);
                            return;
                        }
                        break;
                }
            }
            catch (ObjectDisposedException)
            {
                return;
            }
            catch (NullReferenceException)
            {
                return;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return;
            }
            buffer = new receivebuffer(BitConverter.ToInt32(len, 0));
            socket.BeginReceive(buffer.buffer, 0, buffer.buffer.Length, SocketFlags.None, receivepacketcallabck, null);
        }
            void receivepacketcallabck(IAsyncResult iar)
        {
            int rec = socket.EndReceive(iar);
            if (rec<=0)
            {
                return;
            }
            buffer.bufferstream.Write(buffer.buffer, 0, rec);
            buffer.toreceive -= rec;
            if (buffer.toreceive>0)
            {
                Array.Clear(buffer.buffer, 0, buffer.buffer.Length);
                socket.BeginReceive(buffer.buffer, 0, buffer.buffer.Length, SocketFlags.None, receivepacketcallabck, null);
                return;
            }
            if (datarecieve !=null)
            {
                buffer.bufferstream.Position = 0;
                datarecieve(this,buffer);
            }
            buffer.Dispose();
            receiveasync();
        }
    }
}
