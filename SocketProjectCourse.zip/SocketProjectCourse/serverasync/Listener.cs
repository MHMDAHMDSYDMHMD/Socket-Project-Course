﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net;
using System.IO;
namespace serverasync
{
    class Listener
    {
        public delegate void socketaccepthandler(Socket e);
        public event socketaccepthandler accepted;
        Socket listener;
        public int port;
        public bool running
        {
            get;
            private set;
        }
        public Listener() { port = 0; }
        public void start(int port)
        {
            if (running)
                return;
            listener = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            listener.Bind(new IPEndPoint(0, port));
            listener.Listen(0);
            listener.BeginAccept(acceptcallback, null);
            running = true;
        }
        public void stop()
        {
            if (!running)
            {
                return;
            }
            listener.Close();
            running = false;
        }
        void acceptcallback(IAsyncResult iar)
        {
            try
            {
                Socket s = listener.EndAccept(iar);
                if (accepted != null)
                {
                    accepted(s);
                }
            }
            catch (Exception)
            {

                throw;
            }
            if (running)
            {
                try
                {
                    listener.BeginAccept(acceptcallback, null);
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
    }
}
