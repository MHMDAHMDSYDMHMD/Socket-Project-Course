﻿namespace serverasync
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnlisten1 = new System.Windows.Forms.Button();
            this.pbimage = new System.Windows.Forms.PictureBox();
            this.lsttext1 = new System.Windows.Forms.ListView();
            this.lblinfo1 = new System.Windows.Forms.Label();
            this.btnclose1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbimage)).BeginInit();
            this.SuspendLayout();
            // 
            // btnlisten1
            // 
            this.btnlisten1.Location = new System.Drawing.Point(4, 149);
            this.btnlisten1.Name = "btnlisten1";
            this.btnlisten1.Size = new System.Drawing.Size(103, 23);
            this.btnlisten1.TabIndex = 0;
            this.btnlisten1.Text = "listen";
            this.btnlisten1.UseVisualStyleBackColor = true;
            // 
            // pbimage
            // 
            this.pbimage.Location = new System.Drawing.Point(4, 3);
            this.pbimage.Name = "pbimage";
            this.pbimage.Size = new System.Drawing.Size(214, 140);
            this.pbimage.TabIndex = 1;
            this.pbimage.TabStop = false;
            // 
            // lsttext1
            // 
            this.lsttext1.Location = new System.Drawing.Point(224, 21);
            this.lsttext1.Name = "lsttext1";
            this.lsttext1.Size = new System.Drawing.Size(291, 151);
            this.lsttext1.TabIndex = 2;
            this.lsttext1.UseCompatibleStateImageBehavior = false;
            // 
            // lblinfo1
            // 
            this.lblinfo1.AutoSize = true;
            this.lblinfo1.Location = new System.Drawing.Point(224, 3);
            this.lblinfo1.Name = "lblinfo1";
            this.lblinfo1.Size = new System.Drawing.Size(35, 13);
            this.lblinfo1.TabIndex = 3;
            this.lblinfo1.Text = "label1";
            // 
            // btnclose1
            // 
            this.btnclose1.Location = new System.Drawing.Point(115, 149);
            this.btnclose1.Name = "btnclose1";
            this.btnclose1.Size = new System.Drawing.Size(103, 23);
            this.btnclose1.TabIndex = 0;
            this.btnclose1.Text = "close";
            this.btnclose1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(520, 180);
            this.Controls.Add(this.lblinfo1);
            this.Controls.Add(this.lsttext1);
            this.Controls.Add(this.pbimage);
            this.Controls.Add(this.btnclose1);
            this.Controls.Add(this.btnlisten1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbimage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnlisten1;
        private System.Windows.Forms.PictureBox pbimage;
        private System.Windows.Forms.ListView lsttext1;
        private System.Windows.Forms.Label lblinfo1;
        private System.Windows.Forms.Button btnclose1;
    }
}