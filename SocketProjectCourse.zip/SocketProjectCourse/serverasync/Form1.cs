﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Sockets;
using System.Net;
using System.IO;
namespace serverasync
{
    public partial class Form1 : Form
    {
        Listener lis;
        client cli;

        public Form1()
        {
            InitializeComponent();
            btnlisten1.Click += new EventHandler(btnlisten1_Click);
            btnclose1.Click += new EventHandler(btnclose1_Click);
            FormClosing += new FormClosingEventHandler(Serverasyncmain_FormClosing);
        }

        private void Serverasyncmain_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (cli != null)
            {
                cli.close();
            }
            if (lis != null && lis.running)
            {
                lis.stop();
            }
        }

        private void btnclose1_Click(object sender, EventArgs e)
        {
            if (cli != null)
            {
                cli.close();
                cli = null;
            }

            lis.stop();
            lblinfo1.Text = "connected:null";
            lsttext1.Items.Clear();
            // pbimage.Image = null;
        }

        private void btnlisten1_Click(object sender, EventArgs e)
        {
            lis = new Listener();
            lis.accepted += new Listener.socketaccepthandler(Lis_accepted);
            lis.start(8192);

        }

        private void Lis_accepted(Socket e)
        {
            if (cli != null)
            {
                e.Close();
                return;
            }
            cli = new client(e);
            cli.datarecieve += new client.datarecieveeventhandler(Cli_datarecieve);
            cli.disconnected += new client.disconnectedeventhandler(Cli_disconnected);
            cli.receiveasync();
            Invoke((MethodInvoker)delegate { lblinfo1.Text = $"connected{cli.endppoint.ToString()}"; });
        }
        private void Cli_disconnected(client sender)
        {
            cli.close();
            cli = null;
            Invoke((MethodInvoker)delegate
            {
                lblinfo1.Text = "connected:null";
                DialogResult dres = MessageBox.Show("client disconnected \n clear data ?", "", MessageBoxButtons.YesNo);
                if (dres == DialogResult.Yes)
                {
                    lsttext1.Items.Clear();
                }
            });

        }

        private void Cli_datarecieve(client sender, receivebuffer e)
        {
            BinaryReader br = new BinaryReader(e.bufferstream);
            Commands header = (Commands)br.ReadInt32();
            switch (header)
            {
                case Commands.String:
                    {
                        string s = br.ReadString();
                        Invoke((MethodInvoker)delegate
                        {
                            lsttext1.Items.Add(s);
                        });
                    }
                    break;
                case Commands.Image:
                    {
                        int imagebytelength = (int)br.ReadUInt32();
                        byte[] ibytes = br.ReadBytes(imagebytelength);
                        Invoke((MethodInvoker)delegate
                        {
                            pbimage.Image = Image.FromStream(new MemoryStream(ibytes));
                        });
                        ibytes = null;
                    }
                    break;
                default:
                    break;
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
