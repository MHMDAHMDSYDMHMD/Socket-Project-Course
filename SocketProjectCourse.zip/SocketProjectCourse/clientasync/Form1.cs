﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Net.WebSockets;
using clientasync;
namespace clientasync
{
    public partial class Form1 : Form
    {
        client cli;
        public Form1()
        {
            InitializeComponent();
            btnDisconnect.Click += new EventHandler(BtnDisconnect_CLick);
            btnImage.Click += new EventHandler(BtnImage_Click);
            btnSendText.Click += new EventHandler(BtnSendText_Click);
            btnConnect.Click += new EventHandler(BtnConnect_Click);
            cli = new client();
            cli.onConnet += new client.onconnecteventhandler(Cli_onConnet);
            cli.onsend += new client.onsendeventhandler(Cli_onsend);
            cli.onDisConnet += new client.ondisconnecteventhandler(Cli_onDisConnet);
        }

        private void Cli_onDisConnet(client sender)
        {
            MessageBox.Show("DISconnected");
        }

        private void Cli_onsend(client sender, int sent)
        {
            Invoke((MethodInvoker)delegate
            {
                lbldatasent.Text = string.Format($"data sent :{sent}");
            });
        }
        private void Cli_onConnet(client sender, bool connneted)
        {
            if(connneted)
            MessageBox.Show("CONnected");

        }
        private void BtnConnect_Click(object sender, EventArgs e)
        {
            if (!cli.connected)
            {
                cli.connect("127.0.0.1", 8192);
            }
        }

        private void BtnSendText_Click(object sender, EventArgs e)
        {
            sendtext(textBox1.Text);
           
        }

        private void BtnImage_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog ofp = new OpenFileDialog())
            {
                ofp.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                if (ofp.ShowDialog() == DialogResult.OK)
                {
                    sendimage(ofp.FileName);
                }
            }
        }

        void BtnDisconnect_CLick(object sender ,EventArgs e)
        {
            cli.disconnect();
        }

        private void clientasyncmain_Load(object sender, EventArgs e)
        {

        }
        void sendtext(string text)
        {
            BinaryWriter bw = new BinaryWriter(new MemoryStream());
            bw.Write((int)commands.String);
            bw.Write(text);
            bw.Close();
            byte[] data = ((MemoryStream)bw.BaseStream).ToArray();
            cli.send(data, 0, data.Length);
            data = null;
        }
        void sendimage(string path)
        {
            MemoryStream ms = new MemoryStream();
            BinaryWriter bw = new BinaryWriter(ms);
            byte[] b = File.ReadAllBytes(path);
            bw.Write((int)commands.image);
            bw.Write((int)b.Length);
            bw.Write(b);
            bw.Close();
            b = ms.ToArray();
            ms.Dispose();
            cli.send(b, 0, b.Length);
        }
    }
}
