﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Sockets;
using System.Net.WebSockets;
using System.Net;
namespace clientasync
{
    enum commands
    {
        String = 0,
        image
    }
    class client
    {
        public delegate void onconnecteventhandler(client sender, bool connneted);
        public event onconnecteventhandler onConnet;
        public delegate void onsendeventhandler(client sender, int sent);
        public event onsendeventhandler onsend;
        public delegate void ondisconnecteventhandler(client sender);
        public event ondisconnecteventhandler onDisConnet;
        Socket socket;
        public bool connected
        {
            get
            {
                if (socket != null)
                {
                    return socket.Connected;
                }
                return false;
            }
        }
        public client()
        {
            socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

        }
        public void connect(string ipaddress, int port)
        {
            if (socket == null)
                socket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            socket.BeginConnect(ipaddress, port, connectcallback, null);

        }
        void connectcallback(IAsyncResult iar)
        {
            try
            {
                socket.EndConnect(iar);
                if (onConnet != null)
                {
                    onConnet(this, connected);
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
        public void send(byte[] data, int index, int length)
        {
            socket.BeginSend(BitConverter.GetBytes(length), 0, 4, SocketFlags.None, null, null);
            socket.BeginSend(data, index, length, SocketFlags.None, sendallback, null);
        }
        void sendallback(IAsyncResult iar)
        {
            try
            {
                int sent = socket.EndSend(iar);
                if (onsend !=null)
                {
                    onsend(this, sent);
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"send error \n {ex.Message}");
            }
        }
        public void disconnect()
        {
            try
            {
                if (socket.Connected)
                {
                    socket.Close();
                    socket = null;
                    if (onDisConnet != null)
                    {
                        onDisConnet(this);
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }
    }
}
